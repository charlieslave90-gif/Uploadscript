import { useRouter } from './lib/useRouter';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import CompletePage from './pages/CompletePage';

export default function App() {
  const { path, navigate } = useRouter();

  function renderPage() {
    if (path === '/complete') return <CompletePage />;
    return <HomePage />;
  }

  return (
    <>
      <Header onNavigate={navigate} />
      {renderPage()}
    </>
  );
}
