import { useState } from 'react';
import { CheckCircle, Key, Copy, Check, Zap, AlertCircle, ChevronRight, Code } from 'lucide-react';
import { EDGE_BASE } from '../lib/supabase';

type State = 'idle' | 'loading' | 'success' | 'error';

export default function CompletePage() {
  const [state, setState] = useState<State>('idle');
  const [generatedKey, setGeneratedKey] = useState('');
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  async function handleGenerate() {
    setState('loading');
    setErrorMsg('');
    try {
      const res = await fetch(`${EDGE_BASE}/generate-key`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
      });
      const data = await res.json();
      if (data.key) {
        setGeneratedKey(data.key);
        setState('success');
      } else {
        setErrorMsg(data.error || 'Failed to generate key');
        setState('error');
      }
    } catch {
      setErrorMsg('Network error. Please try again.');
      setState('error');
    }
  }

  async function handleCopy() {
    await navigator.clipboard.writeText(generatedKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="min-h-screen bg-[#080808] text-white">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(34,197,94,0.08),_transparent_50%)] pointer-events-none" />

      <div className="relative max-w-2xl mx-auto px-4 pt-32 pb-20">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-green-500/10 border border-green-500/20 mb-5">
            <CheckCircle size={32} className="text-green-400" />
          </div>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-3">
            Task <span className="text-green-400">Completed!</span>
          </h1>
          <p className="text-zinc-500 text-base">
            You have verified successfully. Generate your one-time access key below.
          </p>
        </div>

        <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-6 md:p-8 mb-6">
          {state !== 'success' ? (
            <div className="text-center">
              <div className="w-14 h-14 rounded-2xl bg-white/[0.05] border border-white/10 flex items-center justify-center mx-auto mb-5">
                <Key size={24} className="text-red-400" />
              </div>
              <h2 className="text-xl font-bold text-white mb-2">Generate Your Key</h2>
              <p className="text-zinc-500 text-sm mb-7 max-w-sm mx-auto">
                Click the button to generate your unique key. This key can only be used once.
              </p>

              {state === 'error' && (
                <div className="flex items-center gap-2.5 bg-red-500/10 border border-red-500/20 text-red-400 text-sm rounded-xl px-4 py-3 mb-5">
                  <AlertCircle size={15} className="flex-shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <button
                onClick={handleGenerate}
                disabled={state === 'loading'}
                className="group inline-flex items-center gap-2.5 bg-red-600 hover:bg-red-500 disabled:bg-red-600/50 disabled:cursor-not-allowed text-white font-bold text-base px-7 py-3.5 rounded-xl transition-all duration-200 shadow-lg shadow-red-600/25 hover:shadow-red-500/35 hover:scale-105 active:scale-95"
              >
                {state === 'loading' ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Generating...</span>
                  </>
                ) : (
                  <>
                    <Zap size={17} />
                    <span>Generate Key</span>
                    <ChevronRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
                  </>
                )}
              </button>
            </div>
          ) : (
            <div>
              <div className="flex items-center gap-2 text-green-400 text-sm font-medium mb-4">
                <CheckCircle size={15} />
                <span>Key generated successfully</span>
              </div>

              <div className="bg-black/40 border border-white/10 rounded-xl p-4 mb-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-zinc-600 mb-1 uppercase tracking-wider">Your Key</p>
                    <p className="text-white font-mono font-semibold text-base md:text-lg tracking-wider truncate">
                      {generatedKey}
                    </p>
                  </div>
                  <button
                    onClick={handleCopy}
                    className="flex-shrink-0 flex items-center gap-1.5 bg-white/[0.06] hover:bg-white/10 border border-white/10 text-zinc-300 hover:text-white text-sm font-medium px-3.5 py-2 rounded-lg transition-all"
                  >
                    {copied ? (
                      <>
                        <Check size={14} className="text-green-400" />
                        <span className="text-green-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy size={14} />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="bg-amber-500/8 border border-amber-500/15 rounded-xl px-4 py-3">
                <p className="text-amber-400/80 text-xs leading-relaxed">
                  <span className="font-semibold text-amber-400">Important:</span> This key can only be used once and will be invalidated after first use. Keep it safe and do not share it.
                </p>
              </div>
            </div>
          )}
        </div>

        {state === 'success' && (
          <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-6">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-7 h-7 rounded-lg bg-white/[0.05] flex items-center justify-center">
                <Code size={14} className="text-zinc-400" />
              </div>
              <h3 className="text-white font-semibold text-sm">How to use in Roblox</h3>
            </div>
            <ol className="space-y-2.5">
              {[
                'Open Roblox and launch the game',
                'Execute the script using your preferred executor',
                'When prompted, paste your key into the input field',
                'Press Enter or click Confirm to activate',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-zinc-500">
                  <span className="flex-shrink-0 w-5 h-5 rounded-full bg-white/[0.05] border border-white/10 text-xs flex items-center justify-center text-zinc-600 mt-0.5">
                    {i + 1}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          </div>
        )}
      </div>
    </div>
  );
}
