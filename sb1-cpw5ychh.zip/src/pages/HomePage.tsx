import { ExternalLink, Shield, Zap, Key, ChevronRight, Lock } from 'lucide-react';

// Replace this with your Linkvertise URL
// In Linkvertise, set the destination URL to: https://your-site.com/complete
const LINKVERTISE_URL = 'https://linkvertise.com/YOUR_LINK_ID/YOUR_LINK_NAME';

export default function HomePage() {
  function handleGetKey() {
    window.location.href = LINKVERTISE_URL;
  }

  const steps = [
    {
      number: '01',
      icon: <ExternalLink size={20} className="text-red-400" />,
      title: 'Complete Linkvertise',
      description: 'Click the button below and complete the short task on Linkvertise to verify you\'re human.',
    },
    {
      number: '02',
      icon: <Zap size={20} className="text-amber-400" />,
      title: 'Generate Your Key',
      description: 'After completing the task, you\'ll be redirected here to instantly generate your unique key.',
    },
    {
      number: '03',
      icon: <Key size={20} className="text-green-400" />,
      title: 'Use in Script',
      description: 'Copy your key and paste it into the Roblox script when prompted. Each key works once.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#080808] text-white">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(220,38,38,0.12),_transparent_60%)] pointer-events-none" />

      <div className="relative max-w-6xl mx-auto px-4 pt-32 pb-20">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-red-600/10 border border-red-600/20 rounded-full px-4 py-1.5 text-sm text-red-400 mb-6">
            <Lock size={13} />
            <span>Protected Script</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-6 leading-none">
            <span className="text-white">GET YOUR</span>
            <br />
            <span className="text-red-500">ACCESS KEY</span>
          </h1>

          <p className="text-zinc-400 text-lg md:text-xl max-w-xl mx-auto mb-10 leading-relaxed">
            Complete a quick Linkvertise task to unlock your unique one-time key and access the script.
          </p>

          <button
            onClick={handleGetKey}
            className="group inline-flex items-center gap-3 bg-red-600 hover:bg-red-500 text-white font-bold text-lg px-8 py-4 rounded-xl transition-all duration-200 shadow-xl shadow-red-600/30 hover:shadow-red-500/40 hover:scale-105 active:scale-95"
          >
            <span>Get My Key</span>
            <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </button>

          <p className="text-zinc-600 text-sm mt-4">
            You will be redirected to Linkvertise &mdash; no downloads required
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-20">
          {steps.map((step) => (
            <div
              key={step.number}
              className="relative bg-white/[0.03] border border-white/[0.08] rounded-2xl p-6 hover:border-white/20 hover:bg-white/[0.05] transition-all duration-200"
            >
              <div className="text-5xl font-black text-white/5 absolute top-4 right-5 select-none">
                {step.number}
              </div>
              <div className="w-10 h-10 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center mb-4">
                {step.icon}
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">{step.title}</h3>
              <p className="text-zinc-500 text-sm leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {[
            { icon: <Shield size={16} className="text-red-400" />, label: 'One-time use keys' },
            { icon: <Zap size={16} className="text-amber-400" />, label: 'Instant generation' },
            { icon: <Lock size={16} className="text-green-400" />, label: 'Secure & verified' },
          ].map((item) => (
            <div
              key={item.label}
              className="flex items-center gap-3 bg-white/[0.02] border border-white/[0.06] rounded-xl px-5 py-3.5"
            >
              <div className="w-7 h-7 rounded-lg bg-white/[0.05] flex items-center justify-center flex-shrink-0">
                {item.icon}
              </div>
              <span className="text-zinc-400 text-sm font-medium">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
