import { useState, useEffect } from 'react';

export function useRouter() {
  const [path, setPath] = useState(window.location.pathname);

  useEffect(() => {
    const handler = () => setPath(window.location.pathname);
    window.addEventListener('popstate', handler);
    return () => window.removeEventListener('popstate', handler);
  }, []);

  function navigate(to: string) {
    window.history.pushState({}, '', to);
    setPath(to);
  }

  return { path, navigate };
}
