import { Gamepad2, Key } from 'lucide-react';

interface HeaderProps {
  onNavigate: (path: string) => void;
}

export default function Header({ onNavigate }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <button
          onClick={() => onNavigate('/')}
          className="flex items-center gap-2.5 group"
        >
          <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center shadow-lg shadow-red-600/30">
            <Gamepad2 size={18} className="text-white" />
          </div>
          <span className="text-white font-bold text-lg tracking-tight group-hover:text-red-400 transition-colors">
            RBX<span className="text-red-500">Keys</span>
          </span>
        </button>
        <div className="flex items-center gap-2 text-sm text-zinc-400">
          <Key size={14} className="text-red-500" />
          <span>Key System</span>
        </div>
      </div>
    </header>
  );
}
