/*
  # Create keys table for Roblox key system

  ## Summary
  Creates a table to store one-time use keys for a Roblox script key system.

  ## New Tables
  - `keys`
    - `id` (uuid, primary key) - Unique identifier
    - `key` (text, unique) - The actual key string in format RBXKEY-XXXX-XXXX-XXXX
    - `created_at` (timestamptz) - When the key was generated
    - `used` (boolean, default false) - Whether the key has been used
    - `used_at` (timestamptz, nullable) - When the key was consumed

  ## Security
  - RLS enabled - edge functions use service role and bypass RLS
  - No public policies since all access goes through secure edge functions
*/

CREATE TABLE IF NOT EXISTS keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  used boolean DEFAULT false,
  used_at timestamptz
);

ALTER TABLE keys ENABLE ROW LEVEL SECURITY;
