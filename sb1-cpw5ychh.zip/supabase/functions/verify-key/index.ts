import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { key } = await req.json();

    if (!key || typeof key !== "string") {
      return new Response(
        JSON.stringify({ valid: false, message: "No key provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: keyRecord, error } = await supabase
      .from("keys")
      .select("id, used")
      .eq("key", key.trim().toUpperCase())
      .maybeSingle();

    if (error || !keyRecord) {
      return new Response(
        JSON.stringify({ valid: false, message: "Key not found" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (keyRecord.used) {
      return new Response(
        JSON.stringify({ valid: false, message: "Key has already been used" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    await supabase
      .from("keys")
      .update({ used: true, used_at: new Date().toISOString() })
      .eq("id", keyRecord.id);

    return new Response(
      JSON.stringify({ valid: true, message: "Key accepted" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ valid: false, message: String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
